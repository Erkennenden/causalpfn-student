"""Current benchmark dependencies."""
